راهنمای استفاده برای Google OAuth

1) عبارت SUPPORT_EMAIL_HERE را در فایل‌های سایت با ایمیل پشتیبانی واقعی خودت جایگزین کن.
2) این فایل‌ها را روی دامنه‌ای که مالکیتش با خودت است منتشر کن.
3) دامنه را در Google Search Console تأیید مالکیت کن.
4) همان دامنه را در Google Auth Platform > Branding > Authorized domains ثبت کن.
5) آدرس index.html را در Homepage بگذار.
6) آدرس privacy.html را در Privacy policy بگذار.
7) آدرس terms.html را در Terms of service بگذار.

نمونه:
Homepage: https://example.com/
Privacy: https://example.com/privacy.html
Terms: https://example.com/terms.html

Package: com.sagacity.hesabak
